/*
 * Application_Code.h
 *
 *  Created on: Jan 17, 2024
 *      Author: Cspon
 */

#ifndef INC_APPLICATION_CODE_H_
#define INC_APPLICATION_CODE_H_

#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_gpio.h"

#define USER_BTN_PORT						GPIOA
#define USER_BTN_PIN						GPIO_PIN_0

#define GREEN_LED_PORT						GPIOG
#define GREEN_LED_PIN						GPIO_PIN_13


#define RED_LED_PORT						GPIOG
#define RED_LED_PIN							GPIO_PIN_14

#define	HIGH								1
#define LOW									0

void appInit();
void blink();
void btnState();

#endif /* INC_APPLICATION_CODE_H_ */


