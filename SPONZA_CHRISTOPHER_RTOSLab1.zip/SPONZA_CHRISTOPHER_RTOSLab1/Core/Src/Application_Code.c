/*
 * Application_Code.c
 *
 *  Created on: Jan 17, 2024
 *      Author: Cspon
 */
#include "Application_Code.h"

void appInit()
{

}

void blink()
{
	HAL_GPIO_TogglePin(RED_LED_PORT, RED_LED_PIN);
	HAL_Delay(1000);
}

void btnState()
{
	if(HAL_GPIO_ReadPin(USER_BTN_PORT, USER_BTN_PIN) == 1)
	{
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, HIGH);
	}
	else
	{
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, LOW);
	}
}
